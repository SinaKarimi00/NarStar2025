﻿using System.Collections.Generic;
using DefaultNamespace.Controllers;
using UnityEngine;
using DefaultNamespace.Factory;
using DefaultNamespace.Updater;


namespace DefaultNamespace
{
    public class Main : MonoBehaviour
    {
        private List<IControllers> controllers;
        private List<IUpdater> neededUpdateClasses;
        private void Awake()
        {
            FactoryClass factory = new FactoryClass();
            controllers = factory.CreateControllers();
        }
    }
}