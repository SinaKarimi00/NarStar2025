﻿using DefaultNamespace.Controllers;
using UnityEngine;


namespace DefaultNamespace.Character_System
{
    public class CharacterController : IControllers
    {
        private string characterPrefabAddress;
        private GameObject character;
        public GameObject Character => character;

        public CharacterController()
        {
            CreateCharacter();
        }

        private void CreateCharacter()
        {
            characterPrefabAddress = "Prefabs/Character/Robot";
            GameObject characterPrefab = Resources.Load(characterPrefabAddress) as GameObject;
            character = Object.Instantiate(characterPrefab);
        }
    }
}