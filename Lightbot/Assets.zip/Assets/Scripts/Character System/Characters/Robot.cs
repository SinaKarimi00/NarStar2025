using UnityEngine;


namespace CharacterSystem
{
    public class Robot : MonoBehaviour
    {

    }
}