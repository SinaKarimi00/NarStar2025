using Animation_System;
using CharacterSystem;

namespace CommandSystem
{
    public class RightRotation : AbstractCommand
    {
        public RightRotation(Robot robot) : base(robot)
        {
        }

        public override void Execute()
        {
            serviceLocator.GetService<AnimationPlayer>().PlayAnimation("TurnRight");
        }
    }
}