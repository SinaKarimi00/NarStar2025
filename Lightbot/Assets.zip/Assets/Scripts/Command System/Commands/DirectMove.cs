using Animation_System;
using CharacterSystem;
using BlockSystem;


namespace CommandSystem
{
    public class DirectMove : AbstractCommand
    {
        private readonly BlockReport blockReport;
        public DirectMove(Robot robot) : base(robot)
        {
            blockReport = new BlockReport(this.robot);
        }

        public override void Execute()
        {
            serviceLocator.GetService<AnimationPlayer>().PlayAnimation(!blockReport.BlockValidation() ? "Move" : "JumpNormal");
        }
    }
}