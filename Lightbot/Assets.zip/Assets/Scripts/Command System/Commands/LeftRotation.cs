using Animation_System;
using CharacterSystem;

namespace CommandSystem
{
    public class LeftRotation : AbstractCommand
    {

        public LeftRotation(Robot robot) : base(robot)
        {
        }

        public override void Execute() => serviceLocator.GetService<AnimationPlayer>().PlayAnimation("TurnLeft");
    }
}