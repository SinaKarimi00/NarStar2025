using Animation_System;
using CharacterSystem;
using BlockSystem;
using UnityEngine;


namespace CommandSystem
{
    public class ChangeLampState : AbstractCommand
    {
        private readonly BlockReport blockReport;
        public ChangeLampState(Robot robot) : base(robot)
        {
            blockReport = new BlockReport(this.robot);
        }

        public override void Execute()
        {
            if (blockReport.IsChangeAbleBlock())
                ChangeBlockMaterial();
            else
                serviceLocator.GetService<AnimationPlayer>().PlayAnimation("ChangeLampState");
        }
        private void ChangeBlockMaterial()
        {
            serviceLocator.GetService<AnimationPlayer>().PlayAnimation("ChangeLampState");
            Color blockColor = blockReport.GetHittedGameObject(blockTag: "LampGround").GetComponent<Renderer>().material.color;
            blockColor = blockColor == Color.yellow ? Color.red : Color.yellow;
            blockReport.GetHittedGameObject(blockTag: "LampGround").GetComponent<Renderer>().material.color = blockColor;
        }

    }
}