﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CharacterSystem;
using UnityEngine;
using CommandSystem;


namespace DefaultNamespace
{
    public class CommandPlayer
    {
        private readonly Animator animator;

        public CommandPlayer(Robot robot)
        {
            animator = robot.GetComponent<Animator>();
        }

        public async void Play(List<ICommand> selectedCommands)
        {
            foreach (var command in selectedCommands)
            {
                command.Execute();
                await Task.Delay(500);
                await WaitForAnimationToFinish(animator);
            }
        }

        private async Task WaitForAnimationToFinish(Animator animator)
        {
            while (animator.GetCurrentAnimatorStateInfo(0).normalizedTime < 1)
            {
                await Task.Delay(5);
            }
        }
    }
}