﻿using System.Collections.Generic;
using DefaultNamespace.Character_System;
using DefaultNamespace.Controllers;
using DefaultNamespace.Level_System;
using DefaultNamespace.UI_System;


namespace DefaultNamespace.Factory
{
    public class FactoryClass
    {
        public List<IControllers> CreateControllers()
        {
            List<IControllers> controllers = new List<IControllers>();
            controllers.Add(new LevelController());
            CharacterController characterController = new CharacterController();
            controllers.Add(characterController);
            controllers.Add(new UIController(characterController.Character));
            return controllers;
        }
    }
}