﻿namespace DefaultNamespace.Controllers
{
    public interface IControllers
    {

    }
}