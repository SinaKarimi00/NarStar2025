﻿namespace Service_Locator
{
    public interface IAnimationService
    {
        void PlayAnimation(string stateNAme);
    }
}