﻿using DefaultNamespace.Controllers;
using UnityEngine;


namespace DefaultNamespace.Level_System
{
    public class LevelController : IControllers
    {
        private string levelPrefabAddress;

        public LevelController( )
        {
            CreateLevel();
        }

        private void CreateLevel()
        {
            levelPrefabAddress = "Prefabs/Levels/Level 1/Level1";
            GameObject levelPrefab = Resources.Load(levelPrefabAddress) as  GameObject;
            Object.Instantiate(levelPrefab);
        }
    }
}