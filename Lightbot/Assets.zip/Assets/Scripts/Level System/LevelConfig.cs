﻿using System.Collections.Generic;
using UnityEngine;

namespace DefaultNamespace.Level_System
{
    [CreateAssetMenu(fileName = "New Level", menuName = "Level config")]
    public class LevelConfig : ScriptableObject
    {
        public List<string> fullNameOfNeededCommands = new List<string>();
    }
}