﻿namespace DefaultNamespace.Updater
{
    public interface IUpdater
    {
        public void Updater();
    }
}