﻿using CharacterSystem;
using DefaultNamespace.Controllers;
using UnityEngine;
using Object = UnityEngine.Object;

namespace DefaultNamespace.UI_System
{
    public class UIController : IControllers
    {
        private GameObject canvas;
        private GameObject canvasPrefab;
        private string canvasPrefabAddress;
        private readonly Robot robot;
        public UIController(GameObject robotGameObject)
        {
            robot = robotGameObject.GetComponent<Robot>();
            Initialize();
            CreateUI();
        }

        private void Initialize()
        {
            canvasPrefabAddress = "Prefabs/Levels/Level 1/Canvas";
            canvasPrefab = Resources.Load(canvasPrefabAddress) as GameObject;
        }

        private void CreateUI()
        {
            canvas = Object.Instantiate(canvasPrefab);
            ButtonManager buttonManager = new ButtonManager(canvas,robot);
            buttonManager.ManageButtons();
        }
    }
}