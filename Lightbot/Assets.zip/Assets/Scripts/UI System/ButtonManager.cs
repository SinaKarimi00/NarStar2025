﻿using System;
using System.Collections.Generic;
using CharacterSystem;
using CommandSystem;
using DefaultNamespace.Level_System;
using SaveLoadSystem;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Object = UnityEngine.Object;


namespace DefaultNamespace.UI_System
{
    public class ButtonManager
    {
        private GameObject buttonPrefab;
        private readonly GameObject canvas;
        private readonly Robot robot;
        public readonly List<ICommand> selectedCommands = new List<ICommand>();
        private LevelConfig levelConfig;

        private delegate void ListenerFunction();

        public ButtonManager(GameObject canvas, Robot robot)
        {
            this.canvas = canvas;
            this.robot = robot;
            Initialize();
        }

        private void Initialize()
        {
            buttonPrefab = Resources.Load("Prefabs/Levels/Button") as GameObject;
            levelConfig = Resources.Load("Level Configs/Level1") as LevelConfig;
        }

        public void ManageButtons()
        {
            CreateFixedButton("Play", PlayButton);
            CreateFixedButton("Reset", ResetGame);
            CreateFixedButton("Save", SaveGame);
            CreateFixedButton("Load", LoadGame);
            CreateNonFixedButtons();
        }

        private void CreateFixedButton(string buttonName, ListenerFunction listenerFunction)
        {
            GameObject buttonGameObject = Object.Instantiate((Object) buttonPrefab, canvas.transform.GetChild(0), true) as GameObject;
            if (buttonGameObject == null) return;
            buttonGameObject.GetComponent<Button>().onClick.AddListener(() => listenerFunction.Invoke());
            SetButtonName(buttonGameObject, buttonName);
        }

        private void CreateNonFixedButtons()
        {
            if (levelConfig == null) return;
            foreach (string item in levelConfig.fullNameOfNeededCommands)
            {
                GameObject newButton = Object.Instantiate((Object) buttonPrefab, canvas.transform.GetChild(0), true) as GameObject;
                if (newButton == null) continue;
                newButton.GetComponent<Button>().onClick.AddListener(() => SetCommandListener(item));
                SetButtonName(newButton, Type.GetType(item)?.Name);
            }
        }

        private void SetCommandListener(string commandName)
        {
            selectedCommands.Add((ICommand) Activator.CreateInstance(Type.GetType(commandName) ?? throw new InvalidOperationException(), new object[] {robot}));
        }

        private void SetButtonName(GameObject button, string commandName)
        {
            button.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = commandName;
        }


        private void PlayButton()
        {
            CommandPlayer commandPlayer = new CommandPlayer(robot);
            commandPlayer.Play(selectedCommands);
        }

        private void ResetGame() => SceneManager.LoadScene(SceneManager.GetActiveScene().name);

        private void SaveGame() => SaveCommand.SaveData(selectedCommands);

        private void LoadGame() => LoadCommand.LoadData(robot, this);
    }
}